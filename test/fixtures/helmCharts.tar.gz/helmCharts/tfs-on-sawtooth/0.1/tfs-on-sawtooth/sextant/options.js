const activated = [{
  value: true,
  title: 'Enabled',
}, {
  value: false,
  title: 'Disabled',
}]

const yesNo = [{
  value: true,
  title: 'Yes',
}, {
  value: false,
  title: 'No',
}]

const consensus = [{
  value: 100,
  title: 'DevMode',
  blurb: 'DevMode is useful for development purposes only. This mechanism useful only on single node networks which provide no real consensus guarantees.',
}, {
  value: 400,
  title: 'PBFT',
  blurb: 'PBFT is a byzantine fault tolerant consensus mechanism offering good scale, and performance. It is tolerant of up to f=(n-1)/3 byzantine or other faults on the network. PBFT is a non-forking algorithm.',
}]

const peering = [{
  value: true,
  title: 'Dynamic',
}, {
  value: false,
  title: 'Static',
}]

module.exports = {
  activated,
  consensus,
  peering,
  yesNo,
}
