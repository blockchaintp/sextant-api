Helm charts will be untarred into this directory
#### helmCharts
  - chartname
    - sextant
        - form.js
        - summary.js
        - options.js
        - details.yaml
    - templates
        - 100
        - ... 300
        - NOTES.txt
    - Chart.yaml
    - values.yaml
    - .helmignore
