# DAML on QLDB Chart

## Configuration

| field | description | type | default |
|- |- |- |- |
| `daml` | settings for DAML subsystem | map | N/A |
| `daml.extra_args` | extra arguments settings for daml-rpc | map | N/A |
| `daml.extra_args.enabled` | if true add the extra arguments | boolean | false |
| `daml.extra_args.arg_str` | string of extra arguments to add | string | nil |
